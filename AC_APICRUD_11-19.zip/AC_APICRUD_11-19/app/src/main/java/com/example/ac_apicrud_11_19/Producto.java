package com.example.ac_apicrud_11_19;

public class Producto {
    private int idProducto;
    private int idEmpresa;
    private String producto1;
    private double precio;
    private String unidadMedida;
    private String categoria;

    public Producto(int idProducto, int idEmpresa, String producto1, double precio, String unidadMedida, String categoria)
    {
        this.idProducto = idProducto;
        this.idEmpresa = idEmpresa;
        this.producto1 = producto1;
        this.precio = precio;
        this.unidadMedida = unidadMedida;
        this.categoria = categoria;
    }

    public Producto() {
    }

    public int getIdProducto() {
        return idProducto;
    }

    public int getIdEmpresa() {
        return idEmpresa;
    }

    public String getProducto1() {
        return producto1;
    }

    public double getPrecio() {
        return precio;
    }

    public String getUnidadMedida() {
        return unidadMedida;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setIdProducto(int idProducto) {
        this.idProducto = idProducto;
    }

    public void setIdEmpresa(int idEmpresa) {
        this.idEmpresa = idEmpresa;
    }

    public void setProducto1(String producto1) {
        this.producto1 = producto1;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public void setUnidadMedida(String unidadMedida) {
        this.unidadMedida = unidadMedida;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }
}
