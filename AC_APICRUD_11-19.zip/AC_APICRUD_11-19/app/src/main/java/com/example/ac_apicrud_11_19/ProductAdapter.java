package com.example.ac_apicrud_11_19;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class ProductAdapter extends ArrayAdapter<Producto> {
    public ProductAdapter(Context context, List<Producto> productos) {
        super(context, 0, productos);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {
        if(convertView == null)
        {
            convertView = LayoutInflater.from(getContext())
                    .inflate(R.layout.item_producto, parent, false);
        }

        Producto p = getItem(position);

        TextView txtProducto = convertView.findViewById(R.id.txtProducto);
        TextView txtPrecio = convertView.findViewById(R.id.txtPrecio);
        TextView txtCategoria = convertView.findViewById(R.id.txtCategoria);
        TextView txtUnidad = convertView.findViewById(R.id.txtUnidad);
        TextView txtEmpresa = convertView.findViewById(R.id.txtEmpresa);

        txtProducto.setText(p.getProducto1());
        txtPrecio.setText(String.valueOf(p.getPrecio()));
        txtCategoria.setText(p.getCategoria());
        txtUnidad.setText(p.getUnidadMedida());
        txtEmpresa.setText(String.valueOf(p.getIdEmpresa()));

        return convertView;
    }
}