package com.example.ac_apicrud_11_19;

import android.os.Bundle;
import android.os.StrictMode;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView listView;
    ArrayList<Producto> listaProductos = new ArrayList<>();
    String apiURL = "http://demoapi.somee.com/api/productos";
    EditText txtProducto, txtPrecio, txtUnidad, txtCategoria;
    Button btnAgregar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder().permitAll().build());

        listView = findViewById(R.id.listViewProductos);

        txtProducto = findViewById(R.id.txtProducto);
        txtPrecio = findViewById(R.id.txtPrecio);
        txtUnidad = findViewById(R.id.txtUnidad);
        txtCategoria = findViewById(R.id.txtCategoria);
        btnAgregar = findViewById(R.id.btnAgregar);

        btnAgregar.setOnClickListener(v -> agregarProducto());

        cargarProductos();
    }

    private void cargarProductos() {
        try {
            URL url = new URL(apiURL);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");

            BufferedReader reader = new BufferedReader(new InputStreamReader(con.getInputStream()));
            StringBuilder respuesta = new StringBuilder();
            String linea;

            while ((linea = reader.readLine()) != null) {
                respuesta.append(linea);
            }

            JSONArray array = new JSONArray(respuesta.toString());
            listaProductos.clear();

            for (int i = 0; i < array.length(); i++) {
                JSONObject obj = array.getJSONObject(i);

                Producto p = new Producto();
                p.setIdProducto(obj.optInt("idProducto", 0));
                p.setIdEmpresa(obj.optInt("idEmpresa", 0));
                p.setProducto1(obj.optString("producto1", "Sin nombre"));
                p.setPrecio(obj.optDouble("precio", 0.0));
                p.setUnidadMedida(obj.optString("unidadMedida", "ND"));
                p.setCategoria(obj.optString("categoria", "ND"));

                listaProductos.add(p);
            }

            ProductAdapter adapter = new ProductAdapter(this, listaProductos);
            listView.setAdapter(adapter);

        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Error al cargar: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void agregarProducto() {
        try {
            URL url = new URL(apiURL);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("POST");
            con.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            con.setDoOutput(true);

            JSONObject nuevo = new JSONObject();
            nuevo.put("idEmpresa", 1);
            nuevo.put("producto1", txtProducto.getText().toString());
            nuevo.put("precio", Double.parseDouble(txtPrecio.getText().toString()));
            nuevo.put("unidadMedida", txtUnidad.getText().toString());
            nuevo.put("categoria", txtCategoria.getText().toString());

            con.getOutputStream().write(nuevo.toString().getBytes("UTF-8"));

            int respuesta = con.getResponseCode();
            if (respuesta == HttpURLConnection.HTTP_OK || respuesta == HttpURLConnection.HTTP_CREATED) {
                Toast.makeText(this, "Producto agregado", Toast.LENGTH_SHORT).show();

                txtProducto.setText("");
                txtPrecio.setText("");
                txtUnidad.setText("");
                txtCategoria.setText("");

                listaProductos.clear();
                cargarProductos();
            } else {
                Toast.makeText(this, "Error al agregar: " + respuesta, Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}
